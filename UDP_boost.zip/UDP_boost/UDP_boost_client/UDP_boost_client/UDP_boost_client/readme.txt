Create header files using 'protoc' compiler:
protobuf version = libprotoc 3.18.0

protoc --cpp_out=. radio.proto
