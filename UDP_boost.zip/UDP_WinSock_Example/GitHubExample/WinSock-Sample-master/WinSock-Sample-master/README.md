# WinSock-Sample
Simple WinSock samples: TCP client and server, UDP client and server

Client sends name of file and server returns file's size in bytes to client
